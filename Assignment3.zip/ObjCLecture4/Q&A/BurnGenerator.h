//
//  BurnGenerator.h
//  ObjCLecture3
//
//  Created by Jacob Henry Prather on 2/4/14.
//  Copyright (c) 2014 jprather. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BlankFiller.h"

@interface BurnGenerator : BlankFiller

-(id)init;

@end
